from .operations import soma
from .operations import subtracao
from .operations import multiplicacao
from .operations import divisao