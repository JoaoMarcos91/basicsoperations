# Minha Biblioteca

Esta é uma biblioteca de exemplo que faz somas!

## Instalação

```bash
pip install minha_biblioteca
# basicsoperations
